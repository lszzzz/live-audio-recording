import mysql from 'mysql'
export const handler = async (event) => {
    // Set up the connection to the MySQL database
    const connection = mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USERNAME,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
        port:   3306
    });
    connection.connect();
    try {
        const data =await new Promise((resolve,reject)=>{
            connection.query('SELECT * from Product',  (error, results, fields) =>{
                resolve(results);
              });
        })
           
        connection.end();
        
        return {
            statusCode: 200,
            body: JSON.stringify({
                products: data
            }),
        };
    } catch (error) {
        console.error('Error fetching products:', error);
        
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: 'Error fetching products',
                error: error.message
            }),
        };
    }
};

handler('dsaf').then(data=>console.log(data))